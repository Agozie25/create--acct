import 'package:flutter/material.dart';

class TermsPage extends StatelessWidget {
  const TermsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Terms and Privacy Policy'),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Title(
                    color: Colors.black,
                    child: const Text(
                      'Overview',
                      style:
                          TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    'Welcome to GroupBuyHive! By using our website and service you agree to comply with and be bound by the following terms and conditions. Please read them carefully. If you do not agree to these terms ,you should not use our services.',
                    style: TextStyle(fontSize: 18),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Title(
                    color: Colors.black,
                    child: const Text(
                      'Acceptance of Terms',
                      style:
                          TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    'By accessing or using the Groupbuyhive website (the "Site") and services,(collectively, the "services"), you agree to bound by these Terms of Service ("Terms"), our Policy Privacy, and all applicable laws and regulations. If you do not agree with any part of these terms, you MUST not use our Services',
                    style: TextStyle(fontSize: 18),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Title(
                    color: Colors.black,
                    child: const Text(
                      'Eligibility',
                      style:
                          TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    'You must be at least 18 yearsold or the age of majority in your jurisdiction to use our services. By buying our services, you represent and warrant that you have the right, authority and capacity to enter into Terms and to abide by all the terms and conditions herein',
                    style: TextStyle(fontSize: 18),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Title(
                    color: Colors.black,
                    child: const Text(
                      'Description Of services',
                      style:
                          TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    'Groupbuyhive is an online group buying platform that allows users to purchase food,grocries and other consumer items in bulk to split costs and save money. We facilitate group buys from various stores ("supply Partners") and integrate with their shipping and return policies.',
                    style: TextStyle(fontSize: 18),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Title(
                    color: Colors.black,
                    child: const Text(
                      'Account Registration',
                      style:
                          TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    'To access certain features of our services, you must register for an account. You agree to provide accurate, current and complete information during the registration process and to update such information to keep it accurate, current and complete. You are responsible for safeguarding your account password and for all activities that occur under your account.',
                    style: TextStyle(fontSize: 18),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Title(
                    color: Colors.black,
                    child: const Text(
                      'Account Registration',
                      style:
                          TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    'To access certain features of our services, you must register for an account. You agree to provide accurate, current and complete information during the registration process and to update such information to keep it accurate, current and complete. You are responsible for safeguarding your account password and for all activities that occur under your account.',
                    style: TextStyle(fontSize: 18),
                  ),
                ],
              ),
              // child: const Text(
              //   'Here are the terms and privacy policy of Foodweysweet...',
              //   style: TextStyle(fontSize: 16),
              // ),
            ),
          ),
        ));
  }
}
